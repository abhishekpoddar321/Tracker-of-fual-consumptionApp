# Changelog

## v1.1.0

- Ability to delete logs
- Added app icon
- Small improvements


## v1.0.0

- Initial release